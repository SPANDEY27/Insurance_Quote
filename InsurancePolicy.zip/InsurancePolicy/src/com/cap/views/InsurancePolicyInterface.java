package com.cap.views;

import java.util.Scanner;

import com.cap.controller.ApplyPolicyController;
import com.cap.controller.CreateProfileController;
import com.cap.controller.LoginController;
import com.cap.controller.ViewPolicyController;
import com.cap.dao.AccountDao;
import com.cap.model.Account;
import com.cap.model.UserRole;

public class InsurancePolicyInterface {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Scanner sc = new Scanner(System.in);
		while(true)
		{
			System.out.println("\t\tInsurance Policy");
			System.out.println("Select \n1.Login \n2.Register");
			int log = sc.nextInt();
			sc.nextLine();
			if(log == 1)
			{
				while (true) {
					System.out.println("Login Page\n\n");
					System.out.println("Enter the username");
					String user = sc.next();
					System.out.println("Enter the password");
					String pass = sc.next();
					int role = 0;
					LoginController lc = new LoginController();
					UserRole userrole = new UserRole();
					userrole = lc.validateLogin(user, pass);
					if (userrole.getRoleCode().equals("insurer")) {
						role = 1;
					}
					if (userrole.getRoleCode().equals("agent")) {
						role = 2;
					}
					if (userrole.getRoleCode().equals("admin")) {
						role = 3;
					}
					switch (role) {
					case 1:
						UserRole user1 = new UserRole();
						System.out.println("Welcome " + user1.getUserName() + "\n\n");
						int choice = 0;
						while (choice != 4) {
							System.out.println("1.Create Profile \n2.Apply for Policy \n3.View Applied Policy \n4.Logout");

							choice = sc.nextInt();
							switch (choice) {
							case 1:
								CreateProfileController cpr = new CreateProfileController();
								cpr.createProfile();
								break;

							case 2:
								ApplyPolicyController apc = new ApplyPolicyController();
								apc.addRequest();
								break;

							case 3:
								ViewPolicyController vpc = new ViewPolicyController();
								AccountDao ad = new AccountDao();
								Account ac = new Account();
								ac = ad.getAcc(user1.getUserName());
								vpc.viewPolicy(ac.getAccountNumber());
								break;

							case 4:
								return;
							}
						}
						break;
					case 2:
						UserRole user2 = new UserRole();
						System.out.println("Welcome " + user2.getUserName() + "\n\n");
						int ch = 0;
						while (ch != 5) {
							System.out.println(
									"1.Create Profile \n2.Policy Creation\n3.Apply for Policy \n4.View Applied Policy \n5.Logout");

							ch = sc.nextInt();
							switch (ch) {
							case 1:
								CreateProfileController cpr = new CreateProfileController();
								cpr.createProfile();
								break;

							case 2:
								break;

							case 3:
								ApplyPolicyController apc = new ApplyPolicyController();
								apc.addRequest();
								break;

							case 4:
								ViewPolicyController vpc = new ViewPolicyController();
								AccountDao ad = new AccountDao();
								Account ac = new Account();
								ac = ad.getAcc(user2.getUserName());
								vpc.viewPolicy(ac.getAccountNumber());
								break;

							case 5:
								return;
							}
						}

						break;
					case 3:
						UserRole user3 = new UserRole();
						System.out.println("Welcome " + user3.getUserName() + "\n\n");
						int ch1 = 0;
						while (ch1 != 6) {
							System.out.println(
									"1.Create Profile \n2.Policy Creation\n3.Apply for Policy \n4.View Applied Policy \n5.Generate Report \n6.Logout");

							ch = sc.nextInt();
							switch (ch) {
							case 1:
								CreateProfileController cpr = new CreateProfileController();
								cpr.createProfile();
								break;

							case 2:
								break;

							case 3:
								ApplyPolicyController apc = new ApplyPolicyController();
								apc.addRequest();
								break;

							case 4:
								ViewPolicyController vpc = new ViewPolicyController();
								AccountDao ad = new AccountDao();
								Account ac = new Account();
								ac = ad.getAcc(user3.getUserName());
								vpc.viewPolicy(ac.getAccountNumber());
								break;

							case 5:break;
							
							case 6:
								return;
							}
						}

						break;

					default:
						System.out.println("No data found..");
						break;
					}

				}

			}
			if(log == 2)
			{
				System.out.println("\t\tRegistration Page\n\n");
				System.out.println("Enter the username");
				String user = sc.next();
				System.out.println("Enter the password");
				String pass = sc.next();
				System.out.println("Roles can be 1.Admin 2.Agent 3.Insured ");
				System.out.println("Enter Role:");
				String role = sc.next();
				
				//call function to add entry to admin approve 
			}
			
		}
		
	}

}

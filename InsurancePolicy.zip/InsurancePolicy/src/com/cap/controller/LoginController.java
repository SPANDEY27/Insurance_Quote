package com.cap.controller;

import com.cap.dao.UserRoleDao;
import com.cap.model.UserRole;

public class LoginController {

	public UserRole validateLogin(String user,String pass)
	{
		UserRole userrole = new UserRole();
		UserRoleDao userdao = new UserRoleDao();
		userrole = userdao.getUserByUserNameAndPassword(user,pass);
		return userrole;
	}
	
	
}

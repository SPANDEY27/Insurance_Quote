package com.cap.controller;

import java.util.Scanner;

import com.cap.dao.PolicyRequestsDao;
import com.cap.model.PolicyRequests;

public class ApplyPolicyController {

	
	public void addRequest()
	{
		PolicyRequests polreq = new PolicyRequests();
		PolicyRequestsDao poldao = new PolicyRequestsDao();
		Scanner sc =new Scanner(System.in);
		System.out.println("Please Provide Following Information ..\n\n");
		
		System.out.print("UserName :");
		polreq.setUserName(sc.next());
		System.out.println();
		
		System.out.print("Bussiness Segment :");
		polreq.setSegment(sc.next());
		System.out.println();
		
		if(poldao.insertRequest(polreq))
		{
			System.out.println("Policy Creation Request has been added..");
		}
		else
		{
			System.out.println("Request Not added..");
		}
		
	}
	

}

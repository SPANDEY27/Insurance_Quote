package com.cap.controller;

import java.util.Scanner;

import com.cap.dao.AccountDao;
import com.cap.dao.UserRoleDao;
import com.cap.model.Account;
import com.cap.model.UserRole;

public class CreateProfileController {

	public void createProfile()
	{
		Account acc = new Account();
		AccountDao accdao = new AccountDao();
		Scanner sc =new Scanner(System.in);
		System.out.println("Please Provide Following Information ..\n\n");
		
		System.out.print("Account Number :");
		acc.setAccountNumber(sc.nextLong());
		System.out.println();
		
		System.out.print("Insured Name :");
		acc.setInsuredName(sc.next());
		System.out.println();
		
		System.out.print("Insured Street : ");
		acc.setInsuredStreet(sc.next());
		System.out.println();
		
		System.out.print("Insured City :");
		acc.setInsuredCity(sc.next());
		System.out.println();
		
		System.out.print("Insured State :");
		acc.setInsuredState(sc.next());
		System.out.println();
		
		System.out.print("Insured Zip : ");
		acc.setZip(sc.nextInt());
		System.out.println();
		
		System.out.print("Bussiness Segment :");
		acc.setBussinessSegment(sc.next());
		System.out.println();
		
		System.out.print("UserName :");
		acc.setUserName(sc.next());
		System.out.println();
		
		UserRole userrole = new UserRole();
		UserRoleDao userdao = new UserRoleDao();
		userrole = userdao.getUser(acc.getUserName());
		boolean usercheck = false;
		if( userrole.getUserName().equals(acc.getUserName()))
		{
			usercheck = true;
		}
		
		if(usercheck)
		{
			accdao.insertProfile(acc);
			System.out.println("Profile Created ....");
		}
		
		
	}
}

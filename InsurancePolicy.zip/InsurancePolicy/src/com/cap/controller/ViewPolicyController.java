package com.cap.controller;

import java.util.ArrayList;
import java.util.List;

import com.cap.dao.PolicyDao;
import com.cap.model.Policy;

public class ViewPolicyController {

	public void viewPolicy(long accno)
	{
		Policy pl = new Policy();
		PolicyDao pd = new PolicyDao();
		
		List<Policy> pli = new ArrayList();
		pli = pd.getUser(accno);
		
		System.out.println("\tPolicy Number \t Policy Premium \t Account Number");
		for(Policy p:pli)
		{
			System.out.println("\t"+p.getPolicyNumber()+"\t"+p.getPolicyPremium()+"\t"+p.getAccounNumber());
		}
	}
}

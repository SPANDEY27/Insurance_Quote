package com.cap.model;

public class BussinessSegment {
	String busSegId;
	int busSegSeq;
	String busSegName;

	public BussinessSegment() {
		super();

	}

	public BussinessSegment(String busSegId, int busSegSeq, String busSegName) {
		super();
		this.busSegId = busSegId;
		this.busSegSeq = busSegSeq;
		this.busSegName = busSegName;
	}

	public String getBusSegId() {
		return busSegId;
	}

	public void setBusSegId(String busSegId) {
		this.busSegId = busSegId;
	}

	public int getBusSegSeq() {
		return busSegSeq;
	}

	public void setBusSegSeq(int busSegSeq) {
		this.busSegSeq = busSegSeq;
	}

	public String getBusSegName() {
		return busSegName;
	}

	public void setBusSegName(String busSegName) {
		this.busSegName = busSegName;
	}

	@Override
	public String toString() {
		return "BussinessSegment [busSegId=" + busSegId + ", busSegSeq=" + busSegSeq + ", busSegName=" + busSegName
				+ "]";
	}

}

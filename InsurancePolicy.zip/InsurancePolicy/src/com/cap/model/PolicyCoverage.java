package com.cap.model;

public class PolicyCoverage {

}

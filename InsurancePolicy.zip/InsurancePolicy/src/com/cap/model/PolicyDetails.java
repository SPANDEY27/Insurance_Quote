package com.cap.model;

public class PolicyDetails {
	
	
	
	long policyNumber;
	
	String questionId;
	
	String answers;

	public PolicyDetails() {
		super();
	}

	public PolicyDetails(long policyNumber, String questionId, String answers) {
		super();
		this.policyNumber = policyNumber;
		this.questionId = questionId;
		this.answers = answers;
	}

	public long getPolicyNumber() {
		return policyNumber;
	}

	public void setPolicyNumber(long policyNumber) {
		this.policyNumber = policyNumber;
	}

	public String getQuestionId() {
		return questionId;
	}

	public void setQuestionId(String questionId) {
		this.questionId = questionId;
	}

	public String getAnswers() {
		return answers;
	}

	public void setAnswers(String answers) {
		this.answers = answers;
	}

	@Override
	public String toString() {
		return "PolicyDetails [policyNumber=" + policyNumber + ", questionId=" + questionId + ", answers=" + answers
				+ "]";
	}

}

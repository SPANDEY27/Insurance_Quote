package com.cap.model;

public class PolicyRequests {

	String userName;
	String Segment;
	public PolicyRequests() {
		super();
		
	}
	public PolicyRequests(String userName, String segment) {
		super();
		this.userName = userName;
		Segment = segment;
	}
	public String getUserName() {
		return userName;
	}
	public void setUserName(String userName) {
		this.userName = userName;
	}
	public String getSegment() {
		return Segment;
	}
	public void setSegment(String segment) {
		Segment = segment;
	}
	@Override
	public String toString() {
		return "PolicyRequests [userName=" + userName + ", Segment=" + Segment + "]";
	}
	
}

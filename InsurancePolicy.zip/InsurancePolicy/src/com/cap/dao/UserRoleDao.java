package com.cap.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;

import com.cap.model.UserRole;

public class UserRoleDao {

	public UserRole getUser(String uname) {
		Connection connection = DatabaseConnection.getConnection();
		try {
			Statement stmt = connection.createStatement();
			ResultSet rs = stmt.executeQuery("SELECT * FROM UserRole WHERE userName=" + uname);
			if (rs.next()) {
				UserRole user = new UserRole();
				user.setUserName(rs.getString(1));
				user.setPassword(rs.getString(2));
				user.setRoleCode(rs.getString(3));
				return user;
			}
		} catch (SQLException ex) {
			ex.printStackTrace();
		}
		return null;
	}

	public UserRole getUserByUserNameAndPassword(String user, String pass) {
		UserRole user1 = new UserRole();
		Connection connection = DatabaseConnection.getConnection();
		try {
			PreparedStatement ps = connection.prepareStatement("SELECT * FROM UserRole WHERE userName=? AND password=?");
			ps.setString(1, user);
			ps.setString(2, pass);
			ResultSet rs = ps.executeQuery();
			if (rs.next()) {
				user1.setUserName(rs.getString(1));
				user1.setPassword(rs.getString(2));
				user1.setRoleCode(rs.getString(3));
				return user1;
			}
		} catch (SQLException ex) {
			ex.printStackTrace();
		}
		return null;
	}
	public boolean insertUser(UserRole user) {
	
		Connection connection = DatabaseConnection.getConnection();
	    try {
	        PreparedStatement ps = connection.prepareStatement("INSERT INTO UserRole VALUES ( ?, ?, ?)");
	        ps.setString(1, user.getUserName());
	        ps.setString(2, user.getPassword());
	        ps.setString(3, user.getRoleCode());
	        int i = ps.executeUpdate();
	      if(i == 1) {
	        return true;
	      }
	    } catch (SQLException ex) {
	        ex.printStackTrace();
	    }
	    return false;
	}
	public boolean updateUser(UserRole user) {
		Connection connection = DatabaseConnection.getConnection();
	    try {
	        PreparedStatement ps = connection.prepareStatement("UPDATE UserRole SET userName=?, password=?, roleCode=? WHERE userName=?");
	        ps.setString(1, user.getUserName());
	        ps.setString(2, user.getPassword());
	        ps.setString(3, user.getRoleCode());
	      
	        int i = ps.executeUpdate();
	      if(i == 1) {
	    return true;
	      }
	    } catch (SQLException ex) {
	        ex.printStackTrace();
	    }
	    return false;
	}
	
	public boolean deleteUser(String uname) {
		Connection connection = DatabaseConnection.getConnection();
	    try {
	        Statement stmt = connection.createStatement();
	        int i = stmt.executeUpdate("DELETE FROM UserRole WHERE userName=" + uname);
	      if(i == 1) {
	    return true;
	      }
	    } catch (SQLException ex) {
	        ex.printStackTrace();
	    }
	    return false;
	}
}

package com.cap.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;

import com.cap.model.PolicyDetails;

public class PolicyDetailsDao {

	public PolicyDetails getUser(long policynumber) {
		Connection connection = DatabaseConnection.getConnection();
		try {
			Statement stmt = connection.createStatement();
			ResultSet rs = stmt.executeQuery("SELECT * FROM PolicyDetails WHERE policyNumber=" + policynumber);
			if (rs.next()) {
				PolicyDetails user = new PolicyDetails();
				user.setPolicyNumber(rs.getLong(1));
				user.setQuestionId(rs.getString(2));
				user.setAnswers(rs.getString(3));
				
				return user;
			}
		} catch (SQLException ex) {
			ex.printStackTrace();
		}
		return null;
	}

	
	public boolean insertUser(PolicyDetails user) {
	
		Connection connection = DatabaseConnection.getConnection();
	    try {
	        PreparedStatement ps = connection.prepareStatement("INSERT INTO PolicyDetails VALUES ( select policy_seq.nextval from dual,?, ?)");
	        
	        ps.setString(2, user.getQuestionId());
	        ps.setString(3, user.getAnswers());
	     
	    
	        int i = ps.executeUpdate();
	      if(i == 1) {
	        return true;
	      }
	    } catch (SQLException ex) {
	        ex.printStackTrace();
	    }
	    return false;
	}
	/*
	 * public boolean updateUser(PolicyDetails user) { Connection connection =
	 * DatabaseConnection.getConnection(); try { PreparedStatement ps = connection.
	 * prepareStatement("UPDATE PolicyDetails SET userName=?, password=?, roleCode=? WHERE userName=?"
	 * ); ps.setString(1, user.getUserName()); ps.setString(2, user.getPassword());
	 * ps.setString(3, user.getRoleCode());
	 * 
	 * int i = ps.executeUpdate(); if(i == 1) { return true; } } catch (SQLException
	 * ex) { ex.printStackTrace(); } return false; }
	 */
	
	public boolean deleteUser(long accno) {
		Connection connection = DatabaseConnection.getConnection();
	    try {
	        Statement stmt = connection.createStatement();
	        int i = stmt.executeUpdate("DELETE FROM PolicyDetails WHERE policyNumber=" + accno);
	      if(i == 1) {
	    return true;
	      }
	    } catch (SQLException ex) {
	        ex.printStackTrace();
	    }
	    return false;
	}

}

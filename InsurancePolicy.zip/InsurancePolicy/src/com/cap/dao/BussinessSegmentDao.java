package com.cap.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;

import com.cap.model.BussinessSegment;

public class BussinessSegmentDao {

			public BussinessSegment getUser(String id) {
			Connection connection = DatabaseConnection.getConnection();
			try {
				Statement stmt = connection.createStatement();
				ResultSet rs = stmt.executeQuery("SELECT * FROM BussinessSegment WHERE busSegId=" + id);
				if (rs.next()) {
					BussinessSegment user = new BussinessSegment();
					user.setBusSegId(rs.getString(1));
					user.setBusSegSeq(rs.getInt(2));
					user.setBusSegName(rs.getString(3));
					
					return user;
				}
			} catch (SQLException ex) {
				ex.printStackTrace();
			}
			return null;
		}

		
		public boolean insertUser(BussinessSegment user) {
		
			Connection connection = DatabaseConnection.getConnection();
		    try {
		        PreparedStatement ps = connection.prepareStatement("INSERT INTO BussinessSegment VALUES ( ?, ?, ?)");
		        ps.setString(1, user.getBusSegId());
		        ps.setInt(2, user.getBusSegSeq());
		        ps.setString(3, user.getBusSegName());
		     
		    
		        int i = ps.executeUpdate();
		      if(i == 1) {
		        return true;
		      }
		    } catch (SQLException ex) {
		        ex.printStackTrace();
		    }
		    return false;
		}
		/*
		 * public boolean updateUser(BussinessSegment user) { Connection connection =
		 * DatabaseConnection.getConnection(); try { PreparedStatement ps = connection.
		 * prepareStatement("UPDATE BussinessSegment SET userName=?, password=?, roleCode=? WHERE userName=?"
		 * ); ps.setString(1, user.getUserName()); ps.setString(2, user.getPassword());
		 * ps.setString(3, user.getRoleCode());
		 * 
		 * int i = ps.executeUpdate(); if(i == 1) { return true; } } catch (SQLException
		 * ex) { ex.printStackTrace(); } return false; }
		 */
		
		public boolean deleteUser(long accno) {
			Connection connection = DatabaseConnection.getConnection();
		    try {
		        Statement stmt = connection.createStatement();
		        int i = stmt.executeUpdate("DELETE FROM BussinessSegment WHERE BussinessSegmentNumber=" + accno);
		      if(i == 1) {
		    return true;
		      }
		    } catch (SQLException ex) {
		        ex.printStackTrace();
		    }
		    return false;
		}

}

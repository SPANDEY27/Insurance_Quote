package com.cap.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;

import com.cap.model.PolicyCoverage;

public class PolicyCoverageDao {

	public PolicyCoverage getUser(String segid) {
		Connection connection = DatabaseConnection.getConnection();
		try {
			Statement stmt = connection.createStatement();
			ResultSet rs = stmt.executeQuery("SELECT * FROM PolicyCoverage WHERE busSegId=" + segid);
			if (rs.next()) {
				PolicyCoverage user = new PolicyCoverage();
				user.setPolCoverageId(rs.getString(1));
				user.setPolCoverageSegment(rs.getInt(2));
				user.setBusSegId(rs.getString(3));
				user.setPolCoverageDesc(rs.getString(4));
				user.setPolCoverageAns1(rs.getString(5));
				user.setPolCoverageAns1Weightage(rs.getInt(6));
				user.setPolCoverageAns2(rs.getString(7));
				user.setPolCoverageAns2Weightage(rs.getInt(8));
				user.setPolCoverageAns3(rs.getString(9));
				user.setPolCoverageAns3Weightage(rs.getInt(10));
				user.setPolCoverageAns4(rs.getString(11));
				user.setPolCoverageAns4Weightage(rs.getInt(12));
				user.setPolCoverageAns5(rs.getString(13));
				user.setPolCoverageAns5Weightage(rs.getInt(14));

				return user;
			}
		} catch (SQLException ex) {
			ex.printStackTrace();
		}
		return null;
	}

	public boolean insertUser(PolicyCoverage user) {

		Connection connection = DatabaseConnection.getConnection();
		try {
			PreparedStatement ps = connection
					.prepareStatement("INSERT INTO PolicyCoverage VALUES ( ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)");
			ps.setLong(1, user.getPolicyCoverageNumber());
			ps.setString(2, user.getInsuredName());
			ps.setString(3, user.getInsuredStreet());
			ps.setString(4, user.getInsuredCity());
			ps.setString(5, user.getInsuredState());
			ps.setInt(6, user.getZip());
			ps.setString(7, user.getBussinessSegment());
			ps.setString(8, user.getUserName());

			int i = ps.executeUpdate();
			if (i == 1) {
				return true;
			}
		} catch (SQLException ex) {
			ex.printStackTrace();
		}
		return false;
	}

	public boolean updateUser(PolicyCoverage user) {
		Connection connection = DatabaseConnection.getConnection();
		try {
			PreparedStatement ps = connection
					.prepareStatement("UPDATE PolicyCoverage SET userName=?, password=?, roleCode=? WHERE userName=?");
			ps.setString(1, user.getUserName());
			ps.setString(2, user.getPassword());
			ps.setString(3, user.getRoleCode());

			int i = ps.executeUpdate();
			if (i == 1) {
				return true;
			}
		} catch (SQLException ex) {
			ex.printStackTrace();
		}
		return false;
	}

	public boolean deleteUser(long accno) {
		Connection connection = DatabaseConnection.getConnection();
		try {
			Statement stmt = connection.createStatement();
			int i = stmt.executeUpdate("DELETE FROM PolicyCoverage WHERE PolicyCoverageNumber=" + accno);
			if (i == 1) {
				return true;
			}
		} catch (SQLException ex) {
			ex.printStackTrace();
		}
		return false;
	}

}

package com.cap.dao;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;

public class DatabaseConnection {

	public static final String URL = "jdbc:mysql://localhost:3306/InsurancePolicy";
	public static final String USER = "root";
	public static final String PASS = "India123";

	public static Connection getConnection() {
		try {
			try {
				Class.forName("com.mysql.jdbc.Driver");
			} catch (ClassNotFoundException e) {

				e.printStackTrace();
			}
			return DriverManager.getConnection(URL, USER, PASS);
		} catch (SQLException ex) {
			throw new RuntimeException("Error connecting to the database", ex);
		}
	}

	/*
	 * public static void main(String[] args) { DatabaseConnection connection = new
	 * DatabaseConnection(); connection.getConnection(); }
	 */
}
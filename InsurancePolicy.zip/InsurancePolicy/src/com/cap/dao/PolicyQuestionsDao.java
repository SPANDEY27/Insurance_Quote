package com.cap.dao;

public class PolicyQuestionsDao {

}

package com.cap.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;

import com.cap.model.PolicyRequests;

public class PolicyRequestsDao {

	
	
	public boolean insertRequest(PolicyRequests user) {
	
		Connection connection = DatabaseConnection.getConnection();
	    try {
	        PreparedStatement ps = connection.prepareStatement("INSERT INTO PolicyRequests VALUES ( ?, ?)");
	        ps.setString(1, user.getUserName());
	        ps.setString(2, user.getSegment());
	        int i = ps.executeUpdate();
	      if(i == 1) {
	        return true;
	      }
	    } catch (SQLException ex) {
	        ex.printStackTrace();
	    }
	    return false;
	}
	
	
	public boolean deleteRequest(String uname) {
		Connection connection = DatabaseConnection.getConnection();
	    try {
	        Statement stmt = connection.createStatement();
	        int i = stmt.executeUpdate("DELETE FROM PolicyRequests WHERE userName=" + uname);
	      if(i == 1) {
	    return true;
	      }
	    } catch (SQLException ex) {
	        ex.printStackTrace();
	    }
	    return false;
	}

}

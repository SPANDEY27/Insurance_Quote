package com.cap.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;

import com.cap.model.Account;

public class AccountDao {
	public Account getUser(long accno) {
		Connection connection = DatabaseConnection.getConnection();
		try {
			Statement stmt = connection.createStatement();
			ResultSet rs = stmt.executeQuery("SELECT * FROM Accounts WHERE accountNumber=" + accno);
			if (rs.next()) {
				Account user = new Account();
				user.setAccountNumber(rs.getLong(1));
				user.setUserName(rs.getString(2));
				user.setInsuredStreet(rs.getString(3));
				user.setInsuredCity(rs.getString(4));
				user.setInsuredState(rs.getString(5));
				user.setZip(rs.getInt(6));
				user.setBussinessSegment(rs.getString(7));
				user.setUserName(rs.getString(8));
				return user;
			}
		} catch (SQLException ex) {
			ex.printStackTrace();
		}
		return null;
	}

	public Account getAcc(String username) {
		Connection connection = DatabaseConnection.getConnection();
		try {
			Statement stmt = connection.createStatement();
			ResultSet rs = stmt.executeQuery("SELECT accountnumber FROM Accounts WHERE username=" + username);
			if (rs.next()) {
				Account user = new Account();
				user.setUserName(rs.getString(1));
				return user;
			}
		} catch (SQLException ex) {
			ex.printStackTrace();
		}
		return null;
	}
	public boolean insertProfile(Account user) {
	
		Connection connection = DatabaseConnection.getConnection();
	    try {
	        PreparedStatement ps = connection.prepareStatement("INSERT INTO Accounts VALUES ( ?, ?, ?, ?, ?, ?, ?, ?)");
	        ps.setLong(1, user.getAccountNumber());
	        ps.setString(2, user.getInsuredName());
	        ps.setString(3, user.getInsuredStreet());
	        ps.setString(4, user.getInsuredCity());
	        ps.setString(5, user.getInsuredState());
	        ps.setInt(6, user.getZip());
	        ps.setString(7, user.getBussinessSegment());
	        ps.setString(8, user.getUserName());
	    
	        int i = ps.executeUpdate();
	      if(i == 1) {
	        return true;
	      }
	    } catch (SQLException ex) {
	        ex.printStackTrace();
	    }
	    return false;
	}
	/*
	 * public boolean updateUser(Account user) { Connection connection =
	 * DatabaseConnection.getConnection(); try { PreparedStatement ps = connection.
	 * prepareStatement("UPDATE Account SET userName=?, password=?, roleCode=? WHERE userName=?"
	 * ); ps.setString(1, user.getUserName()); ps.setString(2, user.getPassword());
	 * ps.setString(3, user.getRoleCode());
	 * 
	 * int i = ps.executeUpdate(); if(i == 1) { return true; } } catch (SQLException
	 * ex) { ex.printStackTrace(); } return false; }
	 */
	
	public boolean deleteUser(long accno) {
		Connection connection = DatabaseConnection.getConnection();
	    try {
	        Statement stmt = connection.createStatement();
	        int i = stmt.executeUpdate("DELETE FROM Accounts WHERE accountNumber=" + accno);
	      if(i == 1) {
	    return true;
	      }
	    } catch (SQLException ex) {
	        ex.printStackTrace();
	    }
	    return false;
	}
}

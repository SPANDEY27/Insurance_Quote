package com.cap.methods;

import java.util.List;

import com.cap.Bean.ReportGeneration;
import com.cap.exception.IQPException;
import com.cap.serviceValidation.InsuranceService;
import com.cap.serviceValidation.InsuranceServiceImpl;

public class GenerateReport {

	InsuranceService insuranceService= new InsuranceServiceImpl();

	public List<ReportGeneration> generateReport(int accountNumber1) throws IQPException{
		return insuranceService.generateReport(accountNumber1);
		
	}
}

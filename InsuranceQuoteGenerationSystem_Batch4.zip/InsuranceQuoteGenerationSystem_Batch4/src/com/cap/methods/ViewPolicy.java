package com.cap.methods;

import java.util.List;

import com.cap.Bean.Policy;
import com.cap.exception.IQPException;
import com.cap.serviceValidation.InsuranceServiceImpl;

public class ViewPolicy {

	InsuranceServiceImpl service=new InsuranceServiceImpl();
	public List<Policy> viewPolicyDetails() throws IQPException{
		
		List<Policy> list=null;
		try {
			list=service.viewPolicyDetails();
		} catch (IQPException e) {
			System.err.println(e.getMessage());
		}
		
		return list;
		
	}
	public Policy getPolicy(String userName)throws IQPException {
		
		return service.getPolicy(userName);
	}

}

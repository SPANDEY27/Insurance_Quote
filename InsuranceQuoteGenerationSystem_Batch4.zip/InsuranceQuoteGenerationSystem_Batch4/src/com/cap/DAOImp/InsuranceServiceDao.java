package com.cap.DAOImp;

import java.util.List;

import com.cap.Bean.Accounts;
import com.cap.Bean.Policy;
import com.cap.Bean.PolicyDetails;
import com.cap.Bean.ReportGeneration;
import com.cap.Bean.UserRole;
import com.cap.exception.IQPException;

public interface InsuranceServiceDao {

	String validLogIn(UserRole role) throws IQPException;
	

	int createAccount(Accounts accounts) throws IQPException;

	boolean getUserName(String userName) throws IQPException;


	int addProfile(UserRole role) throws IQPException;


	boolean existAccount(int accountNumber) throws IQPException;


	String getBuisnessSegment(int accountNumber) throws IQPException;


	String getBuisnessSegmentId(String businessSegment) throws IQPException;


	List<String> getQuestions(String buisnessSegId) throws IQPException;


	List<String> getAnswer(String string) throws IQPException;


	int getWeightage(String string, String option) throws IQPException;


	int insertPolicy(Policy policy)throws IQPException;


	String getQuesId(String question) throws IQPException;


	List<String> getQuestionId(String buisnessSegId) throws IQPException;


	void insertPolicyDetails(PolicyDetails policyDetails) throws IQPException;


	List<Policy> viewPolicyDetails() throws IQPException;


	List<ReportGeneration> generateReport(int accountNumber1) throws IQPException;


	Policy getPolicy(String userName) throws IQPException;

}

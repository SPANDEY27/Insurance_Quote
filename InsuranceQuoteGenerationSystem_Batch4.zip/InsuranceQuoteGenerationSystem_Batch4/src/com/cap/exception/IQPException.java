package com.cap.exception;

public class IQPException extends Exception {
	
	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	public IQPException(String message) {
		
		super(message);
	}

}

package com.cap.serviceValidation;

import java.util.List;

import com.cap.Bean.Accounts;
import com.cap.Bean.Policy;
import com.cap.Bean.PolicyDetails;
import com.cap.Bean.ReportGeneration;
import com.cap.Bean.UserRole;
import com.cap.exception.IQPException;

public interface InsuranceService {

	String validUser(UserRole role) throws IQPException;

	int createAccount(Accounts accounts) throws IQPException;

	boolean validFields(Accounts accounts) throws IQPException;

	boolean getUserName(String userName) throws IQPException;

	boolean checkUserName(String userName) throws IQPException;

	boolean checkPassword(String password) throws IQPException;

	boolean checkUserRole(String userRole) throws IQPException;

	int addProfile(UserRole role) throws IQPException;

	int createPolicy(int accountNumber) throws IQPException;

	boolean validAccountNumber(int accountNumber) throws IQPException;

	boolean existAccount(int accountNumber) throws IQPException;

	String getBuisnessSegment(int accountNumber) throws IQPException;

	String getBuisnessSegmentId(String businessSegment) throws IQPException;

	List<String> getQuestions(String buisnessSegId) throws IQPException;

	List<String> getAnswer(String string) throws IQPException;

	int getWeightage(String string, String string2) throws IQPException;

	int insertPolicy(Policy policy)throws IQPException;

	String getQuesId(String string) throws IQPException;

	List<String> getQuestionId(String bisSegId) throws IQPException;

	void insertPolicyDetails(PolicyDetails policyDetails) throws IQPException;

	List<Policy> viewPolicyDetails() throws IQPException;

	List<ReportGeneration> generateReport(int accountNumber1) throws IQPException;

	Policy getPolicy(String userName) throws IQPException;



}
